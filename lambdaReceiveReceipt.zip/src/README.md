# lambdaReceiveReceipt
Receives photos and uploads them to S3
